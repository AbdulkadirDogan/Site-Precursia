window.onload = () => {
var acc= document.getElementsByClassName('accordion-item');
var i;
var len = acc.length;
for(i = 0; i< len; i++){
	acc[i].addEventListener('click', function(){
		this.classList.toggle('active');
		var contenu = this.nextElementSibling;
		if(contenu.style.maxHeight){
			contenu.style.maxHeight = null;
		}
			else{
				contenu.style.maxHeight = contenu.scrollHeight + 'px'
				icone.rotate(90);
			}
	})
}
}
