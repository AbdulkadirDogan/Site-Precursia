function initMap(){
	var localisation = {lat: 48.839450, lng: 2.390240};
	var map = new google.maps.Map(document.getElementById("map"), {
		zoom: 14,
		center: localisation
	});
	var marker = new google.maps.Marker({
		position:localisation,
		map: map
	});
}