<?php

$user="root";
$mdp="";
$db="precursia";
$serveur="localhost";

$connexion=mysqli_connect($serveur, $user, $mdp, $db);

if($link){
	echo "connexio établie";

}else{
	die(mysqli_connect_error());
}









?>